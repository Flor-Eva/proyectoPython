from django.shortcuts import render
from django.template import loader 

def probandoTemplate(self):
    nomb='Flor'
    ap='Espejo'
    diccionario={'nombre':nomb, 'apellido':ap}
    miHtml = open(r"C:\Users\Metricas\OneDrive - iTrials\Desktop\PreEntrega3\AppVersion1\template1.html")
    #plantilla = Template(miHtml.read()) #Se carga en memoria nuestro documento, template1   
    ##OJO importar template y contex, con: from django.template import Template, Context
    #miHtml.close() #Cerramos el archivo
    #miContexto = Context(diccionario) #EN este caso no hay nada ya que no hay parametros, IGUAL hay que crearlo
    plantilla= loader.get_template('template1.html')
    documento = plantilla.render(diccionario) #Aca renderizamos la plantilla en documento
    return HttpResponse(documento)
